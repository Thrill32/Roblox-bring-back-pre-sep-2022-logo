//https://1000logos.net/wp-content/uploads/2021/04/Roblox-logo.png

function init(){
    //console.log("thrill init start!")
   // var iconlogoclass = document.getElementById('icon-logo');
   var iconlogoclass = document.getElementsByClassName('icon-logo')[0];
    if (iconlogoclass != null) {
       // console.log("Variables set 1 Thrill");
        /*if (iconlogoclass.getAttribute('background-image') != null) {
            console.log("found the attribute thrill!");
            iconlogoclass.setAttribute('background-image', "url(https://1000logos.net/wp-content/uploads/2021/04/Roblox-logo.png)");
        
        } else{
            console.log("wya attribute? thrill");
        }
       */
        
        const style = window.getComputedStyle(iconlogoclass);
        console.log(style["background-image"]);
        
        //iconlogoclass.style.backgroundImage = "url(https://1000logos.net/wp-content/uploads/2021/04/Roblox-logo.png)"
        iconlogoclass.style.backgroundImage = "url(https://download851.mediafire.com/wwwqnwf6fyng/3vpq1noghlhq409/old+roblox+logo+1.png)"
        
    } else {
        console.log("thrill fatal error :sob:");
    }
    
}
//console.log("thrill awaiting site load");
window.onload = init();
//console.log("thrill site load!!");
